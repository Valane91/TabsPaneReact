import TabsTable from './TabsTable'; 
import './TabsTableStyle.css'; 

export default TabsTable; 