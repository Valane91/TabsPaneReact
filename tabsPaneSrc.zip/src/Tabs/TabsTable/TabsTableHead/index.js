import TabsTableHead from './TabsTableHead';
import './TabsTableHeadStyle.css';

export default TabsTableHead;