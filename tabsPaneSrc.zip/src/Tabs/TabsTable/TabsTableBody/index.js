import TabsTableBody from './TabsTableBody'; 
import './TabsTableBodyStyle.css'; 

export default TabsTableBody; 