import TabsTableBodyRow from './TabsTableBodyRow'; 
import './TabsTableBodyRowStyle.css'; 

export default TabsTableBodyRow; 