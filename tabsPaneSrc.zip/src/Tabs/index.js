import Tabs from './Tabs'; 
import './TabsStyle.css'

export default Tabs; 